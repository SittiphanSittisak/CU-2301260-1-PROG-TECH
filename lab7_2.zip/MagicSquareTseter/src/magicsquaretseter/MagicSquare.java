/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package magicsquaretseter;

/**
 *
 * @author Garin
 */
public class MagicSquare {
    private int i,j,k,n;
    private String s="";
    private Integer[][] N ;
    MagicSquare(int n)
    {
        this.n=n;
        N = new Integer[n][n];
        i=n-1;
        j=(n/2);
        k=1;
        N[i][j]=k;   
        //System.out.println("i = "+i+"\tj = "+j);
        for(k=2;k<=n*n;k++)
        {
            i++;
            j++;
            //System.out.println("i="+i+"\tj="+j+"\tk="+k+"\tn="+n);
            if(i>n-1 && !((i-1==n-1 && j-1==n-1)))
            {
                i=0;
                //System.out.println("i=0");
            }
            if(j>n-1 && !((i-1==n-1 && j-1==n-1)))
            {
                j=0;
                //System.out.println("j=0");
            }
            if((i-1==n-1 && j-1==n-1) || N[i][j]!=null)
            {
                i-=2;
                j--;
                //System.out.println("i--");
            }
            //System.out.println("Final: i="+i+"\tj="+j+"\tk="+k);
            //System.out.println("N1 = "+N[i][j]);
            N[i][j]=k;
            //System.out.println("N2 = "+N[i][j]);
            //System.out.println("i = "+i+"\tj = "+j);
        }
        //System.out.println("N3 = "+N[i][j]);
    }
    public String toString()
    {
        i=0;
        j=0;
        for(i=0;i<n;i++)
        {
            for(j=0;j<n;j++)
            {
                s+=Integer.toString(N[i][j]);
                s+="\t";
                //System.out.println(Integer.toString(N[i][j]));
            }
            s+="\n\n\n";
        }
        return s;
    }
}
