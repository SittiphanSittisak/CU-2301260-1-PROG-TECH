/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package magicsquaretseter;

import java.util.Scanner;
/**
 *
 * @author Garin
 */
public class MagicSquareTseter {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner ip = new Scanner(System.in);
        int n = 0;
        while(n%2==0 || n<0)
        {
            System.out.print("n = ");
            n=ip.nextInt();
        }
        MagicSquare ms = new MagicSquare(n);
        System.out.println(ms.toString());
    }
    
}
