/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cashregistertester;

/**
 *
 * @author Garin
 */
public class CashRegister {
    private double sum, tax , price = 0 , t = 0;
    public CashRegister(double tax)
    {
        this.tax = tax;
    }
public void recordPurchase(double price)
    {
        this.price += price;
    }
public void recordTaxablePurchase(double price)
    {
        this.price += price;
        t += price*(tax/100);
    }
public void getTotalTax()
{
    sum = price + t;
}
public double giveChange(double pay)
    {
        return pay - sum;
    }
}
