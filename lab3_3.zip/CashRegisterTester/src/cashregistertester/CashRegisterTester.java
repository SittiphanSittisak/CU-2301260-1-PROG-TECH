/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cashregistertester;

/**
 *
 * @author Garin
 */
public class CashRegisterTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CashRegister cash = new CashRegister(7);
        cash.recordPurchase(50);
        cash.recordPurchase(10);
        cash.recordTaxablePurchase(20);
        cash.getTotalTax();
        System.out.println("Your change is " + cash.giveChange(100));
    }
    
}
