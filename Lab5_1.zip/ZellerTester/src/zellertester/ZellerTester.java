package zellertester;

import java.util.Scanner;

public class ZellerTester {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int year,month,dayOfMonth;
        System.out.print("Enter year (e.g., 2012): ");
        year=in.nextInt();
        System.out.print("Enter month (1-12): ");
        month=in.nextInt();
        System.out.print("Enter day of the month (1-31): ");
        dayOfMonth=in.nextInt();
        Zeller zl = new Zeller(dayOfMonth,month,year);
        System.out.println("Day of the week is "+zl.getDayOfWeek());
    }

}
