    package zellertester;

public class Zeller {
    private int dayOfMonth; //เก็บวันของเดือน
    private int month; //เก็บเดือน
    private int year; //เก็บป
    private int h,j,k;
    private String thisday;
    public Zeller(int dayOfMonth, int month, int year)
    {
        this.dayOfMonth=dayOfMonth;
        this.month=month;
        this.year=year;
        switch(month)
        {
            case 1: this.month=13; this.year-=1; break;
            case 2: this.month=14; this.year-=1; break;
        }
    }
    public enum Day
    {
        SUNDAY("Sunday"),MONDAY("Monday"),TUESDAY("Tuesday"),WEDNESDAY("Wednesday"),THURSDAY("Thursday"),FRIDAY("Friday"),SATURDAY("Saturday");
        public final String day1;
        Day (String day)
        {
            this.day1=day;
        }
    }
     public String getDayOfWeek()
     {
         j=year/100;
         k=year%100;
         h=(dayOfMonth+((26*(month+1))/10)+k+(k/4)+(j/4)+(5*j))%7;
         switch(h)
         {
             case 0: Day enumDay0 = Day.SATURDAY; thisday=enumDay0.day1; break;
             case 1: Day enumDay1 = Day.SUNDAY; thisday=enumDay1.day1; break;
             case 2: Day enumDay2 = Day.MONDAY; thisday=enumDay2.day1; break;
             case 3: Day enumDay3 = Day.TUESDAY; thisday=enumDay3.day1; break;
             case 4: Day enumDay4 = Day.WEDNESDAY; thisday=enumDay4.day1; break;
             case 5: Day enumDay5 = Day.THURSDAY; thisday=enumDay5.day1; break;
             case 6: Day enumDay6 = Day.FRIDAY; thisday=enumDay6.day1; break;
         }
         return thisday;
     }
}
