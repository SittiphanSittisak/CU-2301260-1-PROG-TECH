/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package letterprinter;

/**
 *
 * @author Garin
 */
public class LetterPrinter {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Letter L = new Letter("Jade","Clarissa");
        L.addLine("");
        L.addLine("We must find Simon quickly.");
        L.addLine("He might be in danger.");
        L.addLine("");
        L.addLine("Sincerely,");
        System.out.println(L.getText());
    }
    
}
