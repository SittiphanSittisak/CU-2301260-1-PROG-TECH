/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package letterprinter;

/**
 *
 * @author Garin
 */
public class Letter {
    private String l = "Dear ",to;
    public Letter(String from, String to)
    {
        l += from + ":\n";
        this.to = to;
    }
    public void addLine(String line)
    {
        l += line + "\n";
    }
    public String getText()
    {
        l += "\n" + to + "\n";
        return l;
    }
}
