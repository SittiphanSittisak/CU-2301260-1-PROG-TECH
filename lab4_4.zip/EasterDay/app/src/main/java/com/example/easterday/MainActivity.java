package com.example.easterday;

import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //TextBox
        final EditText txtName = (EditText)findViewById(R.id.editText);
        //Submit Button
        final Button subMitfrm = (Button)findViewById(R.id.button);
        //Value Text
        final TextView showMsg = (TextView) findViewById(R.id.textView);

        //Click Event
        subMitfrm.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int y = Integer.parseInt(txtName.getText().toString());
                int a,b,c,d,e,g,h,j,k,m,r,n,p;
                a = y%19;
                b = y/100;
                c = y%100;
                d = b/4;
                e = b%4;
                g = (8*b+13)/25;
                h = (19*a+b-d-g+15)%30;
                j = c/4;
                k = c%4;
                m = (a+11*h)/319;
                r = (2*e+2*j-k-h+m+32)%7;
                n = (h-m+r+90)/25;
                p = (h-m+r+n+19)%32;
                String EasterDay=Integer.toString(p)+"/"+Integer.toString(n)+"/"+Integer.toString(y);
                showMsg.setText("Easter Day!\n"+EasterDay);
            }
        });
    }
}
