
package cannnonballtester;


public class CannnonBallTester {


    public static void main(String[] args) {
        CannonBall ball = new CannonBall(100); //กําหนดความเร็วตั้งต้นใหลูกกระสุนปืนใหญ่มีควาเปืน 100 m/sec
        ball.simulatedFlight();
        System.out.printf("Distance from calculus equation: %.3f",ball.calculusFlight(ball.getSimulatedTime()));

    }
    
}
