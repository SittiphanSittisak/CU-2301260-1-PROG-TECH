
package cannnonballtester;


public class CannonBall {
    private double initV; //ความเร็วตั้งต้น
    private double simS; //ระยะทางที่คํานวณได้จากวิธี simulation
    private double simT; //เวลาที่ใช้ในวิธี simulation
    public static final double g = 9.81;
    public int count=0;
    public CannonBall(double initV)
    {
        this.initV=initV;
    }
    public void simulatedFlight() //คํานวณหาระยะทางที่ลูกกระสุนปืนใหญ่เคลื่อนที่จนกระทั่งความเร็วเป็น 0 และตกกลับลงบนพื้นโลก โดยอัพเดตระยะทางและความเร็ว 100 ครั้งต่อวินาที และพิมพ์ระยะทางที่ลูกบอล เคลื่อนไปได้ทุก ๆ 1 วินาที และระยะทางสุดท้ายก่อนตกกลับลงมา
    {
        simT=0;
        simS=0;
        while(initV>0)
        {
            simT+=0.01;
            initV-=g*0.01;
            simS+=initV*0.01;
            count+=1;
            if(count%100==0)
            {
                System.out.printf("Distance on %d sec: %.3f\n",count/100,simS);
            }
        }
        System.out.printf("Final distance: %.3f Total time: %.2f\n",simS,simT);
    }
    public double calculusFlight(double t) //คํานวณระยะทางที่ลูกกระสุนปืนใหญ่เคลื่อนที่ไปได้ หากใช้ระยะเวลา t
    {
        return 100*t-(g*t*t)/2;
    }
    public double getSimulatedTime() //คืนระยะเวลาทั้งหมดที่ใช้จนลูกกระสุนปืนตกกลับลงพื้นในวิธี simulation
    {
        return simT;
    }
    public double getSimulatedDistance() //คืนระยะทางที่ลูกกระสุนปืนใหญ่เคลื่อนที่ไปก่อนตกกลับลงพื้น
    {
        return simS;
    }
}
