/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Garin
 */
import java.util.Scanner;
public class TimeIntervalTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.printf("Enter start time: ");
        String st,et;
        st = in.nextLine();
        System.out.printf("Enter end time: ");
        et = in.nextLine();
        TimeInterval ti = new TimeInterval(st,et);
        System.out.println(ti.getHours()+" hours "+ti.getMinutes()+" minutes ");
    }
    
}
