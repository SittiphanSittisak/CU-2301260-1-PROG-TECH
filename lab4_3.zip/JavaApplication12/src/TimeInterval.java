/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Garin
 */
public class TimeInterval {
    private int hs,he,ms,me,check;
    public TimeInterval(String st, String et) {
        ms = Integer.parseInt(st.substring(2,4));   //มีวิธีเเปลงเป็นตัวเลขเเล้วมาคำนวณ เเต่บทนี้ต้องการใช้ .substring() T___T
        me = Integer.parseInt(et.substring(2,4))+60;
        hs = Integer.parseInt(st.substring(0,2));
        he = Integer.parseInt(et.substring(0,2))-1;
        check=Integer.parseInt((Double.toString((me-ms)/60)).substring(0,1));
    }
    public int getMinutes()
    {
        return (me-ms)-(check*60);
    }
    public int getHours()
    {
        return he-hs+this.check;
    }
}
