/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package insectpopulationtester;

/**
 *
 * @author Garin
 */
public class InsectPopulation {
    private double n;
    public InsectPopulation(double n){
        this.n=n;
    }
    public void breed() { n *= 2; }
    public void spray() { n -= n*0.1; }
    public double getNumInsect() { return n; }
    
}
