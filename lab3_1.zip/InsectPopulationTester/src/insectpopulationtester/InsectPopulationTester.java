/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package insectpopulationtester;

public class InsectPopulationTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        InsectPopulation growth = new InsectPopulation(10);
        growth.breed();
        growth.spray();
        System.out.println("Number of insects: " + growth.getNumInsect());
        growth.breed();
        growth.spray();
        System.out.println("Number of insects: " + growth.getNumInsect());
        growth.breed();
        growth.spray();
        System.out.println("Number of insects: " + growth.getNumInsect());
    }
    
}
