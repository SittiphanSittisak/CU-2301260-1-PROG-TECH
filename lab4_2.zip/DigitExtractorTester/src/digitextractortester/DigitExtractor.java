/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package digitextractortester;

/**
 *
 * @author Garin
 */
public class DigitExtractor {
    //ประกาศ instance variable ที่เหมาะสม
    private String str;
    private int count1=5, count2=6;
    //Constructor รับเลขจํานวนเต็มที่ต้องการจะแยกออกทีละหลัก
    public DigitExtractor(int anInteger) {
        str = Double.toString((anInteger-(anInteger/100000)*100000)*0.00001+1.000001).substring(2,7); //แก้ไขการมีตัวเลขเกิน 5 หลักและตัวเลขมีค่าเป็น 0 เรียบร้อย*****
    // str = Double.toString(Double.parseDouble(anInteger));
    //เติมโค้ดในส่วนนี้
    }
    // คืนเลขหลักถัดไปที่ต้องการแยกออกมา
    public int nextDigit() {
        count1 -= 1;
        count2 -= 1;
        return Integer.parseInt(str.substring(count1,count2));
    //เติมโค้ดในส่วนนี้
}
}
