
package linetester;

public class LineTester {

    public static void main(String[] args) {
        Line l1 = new Line(1,-24);
        Line l2 = new Line(29,5,53,29);  
        System.out.println("Are the two lines equals?: "+l1.equals(l1.m, l2.m, l1.b, l2.b, l1.x, l2.x));
        System.out.println("Are the two lines parallel?: "+l1.isParallel(l1.m, l2.m));
        System.out.println("Do the two lines intersect?: "+l1.isIntersect(l1.m, l2.m));
        if(l1.isIntersect(l1.m, l2.m))
        {
            l1.getIntersectionPoint(l1.m,l2.m,l1.c,l2.c,l1.x,l2.x);
            System.out.printf("Point of intersection: %.2f,%.2f\n",l1.output1,l1.output2);
        }
    }
    
}
