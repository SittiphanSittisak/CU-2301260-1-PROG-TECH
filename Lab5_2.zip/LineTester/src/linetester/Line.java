
package linetester;

import java.awt.geom.Point2D;
import static java.lang.Double.NaN;
import static java.lang.Double.isNaN;

public class Line {
    public double m; // m เก็บความชันของเส้นตรง (มีค่าเป็น NaN สําหรับ vertical line)
    public double b; // b เก็บจุดตัดแกน y (มีค่าเป็น NaN สําหรับ vertical line) >> ตัดเเกน y เมื่อ mx=0 >> m=0 >> y != NaN
    public double x; // x เก็บจุดตัดแกน x สําหรับ vertical line (มีค่าเป็น NaN สําหรับเส้นตรงปกติ)
    public double c; // y = mx+c -> c = y-mx
    public double output1,output2;
    public Line(double x, double y, double m) //รับจุดหนึ่งจุดที่อยู่บนเส้น (x,y) และความชันของเส้น (m) 
    {
        this.m=m;
        if(this.m==0)
        {
            this.b=y-m*x;
            this.x=NaN;
        }
        else
        {
            this.x=x-(y/m);
            this.b=NaN;
        }
        this.c=(y-(this.m*x));
        
    }
    public Line(double x1, double y1, double x2, double y2) //รับจุดสองจุดที่อยู่บนเส้น (x1,y1), (x2,y2)
    {
        this.m=(y2-y1)/(x2-x1);
        if(this.m==0)
        {
            this.b=y1-(x1*((y2-y1)/(x2-x1)));
            this.x=NaN;
        }
        else
        {
            this.x=x1-y1/((y2-y1)/(x2-x1));
            this.b=NaN;
        }
        this.c=(y1-(this.m*x1));
    }
    public Line(double m, double b) //รับความชัน (m) และจุดตัดแกน (b) ในรูปสมการ y = mx+b
    {
        this.m=m;
        if(this.m==0)
        {
            this.b=b;
            this.x=NaN;
        }
        else
        {
            this.x=-b/m;
            this.b=NaN;
        }
        this.c=b;
    }
    public Line(double a) //สําหรับ vertical line ซึ่งสมการอยู่ในรูป x = a
    {
        this.m=NaN;
        this.x=a;
        this.b=NaN;
        this.c=NaN;
    }
    public boolean equals(double Line, double line, double B, double b, double X, double x) //ตรวจสอบว่าเส้นตรงสองเส้นเท่ากันหรือไม่ ให้ตรวจสอบโดยดูจากเส้นตรงสองเส้นเท่ากันหากมีความชันเท่ากัน และจุดตัดแกนเท่ากัน
    {
        return ((Line==line)&&((B==b)||(X==x)));
    }
    public boolean isParallel(double Line, double line) //ตรวจสอบว่าเส้นตรงสองเส้นขนานกันหรือไม่ ให้ตรวจสอบโดยดูจากเส้นตรงสองเส้นขนานกันหากมีความชันเท่ากัน
    {
        return (Line==line || (isNaN(Line)&&isNaN(line)));
    }
    public boolean isIntersect(double Line, double line) //ตรวจสอบว่าเส้นตรงสองเส้นตัดกันหรือไม่ ให้ตรวจสอบโดยดูจากเส้นตรงสองเส้นตัดกันหากมันไม่ขนานกัน
    {
        return (!(Line==line || (isNaN(Line)&&isNaN(line))));
    }
    public Point2D.Double getIntersectionPoint(double Line, double line, double C, double c, double X, double x) //หาจุดตัดของเส้นตรงสองเส้นหากตัดกัน ในกรณีที่เส้นตรงสองเส้นเป็นเส้นเดียวกันถือว่าจุดตัดคือทุกจุดบนเส้น (infinity) (ใช้ความรู้คณิตศาสตร์ม.ปลายในการหาจุดตัด)
    {
        if((isNaN(C) && !isNaN(c)))
        {
            
            this.output1=X;
            this.output2=line*X+c;
        }
        else if((!isNaN(C) && isNaN(c)))
        { 
            this.output1=x;
            this.output2=Line*x+C;
        }
        else
        {
            this.output1=(C-c)/(line-Line);
            this.output2=((Line*(C-c))+(C*(line-Line)))/(line-Line);
            
        }
        return null;
    }
}
