package com.example.guessanumber;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        //TextBox
        final EditText et = (EditText)findViewById(R.id.answer);
        //Submit Button
        final Button bt = (Button)findViewById(R.id.guess);
        //Value Text
        final TextView tv = (TextView) findViewById(R.id.textAnswer);
        Random rd = new Random();
        final int ans=rd.nextInt(100)+1;

        //Click Event
        bt.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int ip=Integer.parseInt(et.getText().toString());
                if(ans==ip)
                {
                    Intent intent = new Intent(Main2Activity.this, Main3Activity.class);
                    startActivity(intent);
                    finish();
                }
                else if(ans<ip)
                {
                    tv.setText("Your guess is too high");
                }
                else if(ans>ip)
                {
                    tv.setText("Your guess is too low");
                }
            }
        });
    }
}
