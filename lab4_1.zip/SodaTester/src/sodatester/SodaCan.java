/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sodatester;

/**
 *
 * @author Garin
 */
public class SodaCan {
    private double h,r;
    public SodaCan(double h,double d) 
    {
           this.h = h;
           r = d/2;
    }
    public double getVolume()
    {
        return Math.pow(r,2)*Math.PI*h;
    }
    public double getSurfaceArea()
    {
        return 2*Math.PI*r*h+2*Math.PI*Math.pow(r,2);
    }
}
