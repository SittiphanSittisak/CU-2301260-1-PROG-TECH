
package citygridtester;

import java.util.Random;
public class CityGrid {
    private int xCoor; //เก็บพิกัดของชายผู้หนึ่งในแนวแกน x
    private int yCoor; //เก็บพิกัดของชายผู้หนึ่งในแนวแกน y
    private int gridSize; //เก็บขนาดของเมือง
    CityGrid(int gridSize)
    {
        this.gridSize=10;
        this.xCoor=gridSize/2;
        this.yCoor=gridSize/2;
    }
    public void walk() // ชายผู้หนึ่งจะเดินเพียงหนึ่งก้าว โดยสามารถเดินได้ 4 ทิศ คือเดินขึ้น (y--) ลง (y++) ซ้าย (x--) ขวา (x++)
    {
        Random rd = new Random();
        switch(rd.nextInt(4))
        {
            case 0: xCoor++; break;
            case 1: xCoor--; break;
            case 2: yCoor++; break;
            case 3: yCoor--; break;
        }
    }
    public boolean isInCity() //คืนค่าจริง หากชายผู้หนึ่งยังคงอยู่ในเมือง
    {
        return (0<=xCoor && xCoor<=10 && 0<=yCoor && yCoor<=10);
    }
    public void reset() //reset ตําแหน่งของชายผู้หนึ่งให้กลับมาอยู่ที่กลางเมือง
    {
        xCoor=gridSize/2;
        yCoor=gridSize/2;
    }
}
