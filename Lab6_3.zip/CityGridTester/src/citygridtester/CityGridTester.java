
package citygridtester;


public class CityGridTester {


    public static void main(String[] args) {
        CityGrid citygrid = new CityGrid(10);
        int highestWalk=0;
        double averageWalk=0;
        for(int i=0;i<10000;i++)
        {
            for(int j=0;j<1000 && citygrid.isInCity();j++)
            {
                citygrid.walk();
                if(!(j+1<1000 && citygrid.isInCity()))
                {
                    averageWalk+=j+1;
                    if(j+1>highestWalk)
                    {
                        highestWalk=j+1;
                    }
                }
            }
            citygrid.reset();
            if(!(i+1<10000))
            {
                averageWalk=averageWalk/(i+1);
            }
        }
        System.out.printf("Average number of steps that a person can take and is still in the city: %.2f\n",averageWalk);
        System.out.println("Maximum number of steps that a person can take and is still in the city: "+highestWalk);
    }
    
}
