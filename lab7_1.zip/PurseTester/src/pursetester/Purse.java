
package pursetester;

import java.util.ArrayList;


public class Purse {
    public ArrayList<String> purse = new ArrayList<String>();
    public void addCoin(String coinName) //เพิ่มเหรียญลงในกระเป๋าสตางค์
    {
        this.purse.add(coinName);
    }
     
    public String toString() //คืน String ที่แสดงเหรียญในกระเป๋าสตางค์ในรูปแบบ Purse[Quarter,Dime,Nickel,Dime]
    {
        String tostring="Purse";
        tostring+=purse;
        return tostring;
    }
    public ArrayList<String> reverse() //กลับลําดับของเหรียญในกระเป๋าสตางค์ Purse[Quarter,Dime,Nickel,Dime] -> Purse[Dime,Nickel,Dime,Quarter]
    {
        String copy;
        //System.out.println("ERROR: 1");
         for(int i=0;i<purse.size()/2;i++)
         {
             //System.out.println("ERROR: 2");
             copy=purse.get(i);
             //System.out.println("ERROR: 3");
             purse.set(i, purse.get(purse.size()-i-1));
             //System.out.println("ERROR: 4");
             purse.set(purse.size()-i-1, copy);
             //System.out.println("ERROR: 5");
         }
        return null;
    }
    public void transfer(Purse other) //ย้ายเหรียญจากกระเป๋าหนึ่งไปสู่อีกกระเป๋าหนึ่ง
    {
        //System.out.println("other: "+other);
        int j=purse.size();
        //System.out.println("ERROR: 6");
        for(int i=0;i<j;i++)
        {
            //System.out.println("ERROR: 7");
            other.addd(purse.get(0));
            //System.out.println("ERROR: 8");
            purse.remove(0);
        }
    }
    public boolean sameContents(Purse other) //คืนค่า true หากลําดับของเหรียญในกระเป๋าสองใบตรงกัน
    {
        if(purse.size()!=other.sizee())
        {
            return false;
        }
        else
        {
            int j=1;
            for(int i=0;i<purse.size();i++)
            {
                if(purse.get(i)!=other.gett(i))
                {
                    j=0;
                    break;
                }
            }
            return j==1;
        }
    }
    public boolean sameCoins(Purse other) //คืนค่า true หากชนิดและจํานวนของเหรียญในกระเป๋าสองใบมีค่าเหมือนกัน true สําหรับ Purse[Quarter,Dime,Nickel,Dime] และ Purse[Nickel,Dime,Dime,Quarter]
    {
        //System.out.println("ERROR: 9");
        if(purse.size()!=other.sizee())
        {
            //System.out.println("ERROR: 10");
            return false;
        }
        else
        {
            ArrayList<String> p = new ArrayList<String>(),o = new ArrayList<String>();
            //System.out.println("ERROR: 11");
            for(int i=0;i<purse.size();i++)
            {
                //System.out.println("ERROR: 12");
                //System.out.println(p);
                p.add(purse.get(i));
                //System.out.println("ERROR: 13");
                o.add(other.gett(i));
            }
            for(int i=0;i<purse.size();i++)
            {
                //System.out.println("p: "+p);
                //System.out.println("o: "+o);
                for(int j=0;j<o.size();j++)
                {
                    if(p.get(0).compareTo(o.get(j))==0)
                    {
                        //System.out.println("p: "+p.get(0));
                        //System.out.println("o: "+o.get(j));
                        p.remove(0);
                        o.remove(j);
                        break;
                    }
                }
            }
            return p.size()==0 && o.size()==0;
        }
    }
    public String gett(int i)
    {
        return purse.get(i);
    }
    public int sizee()
    {
        return purse.size();
    }
    public void addd(String str)
    {
        purse.add(str);
    }
}
