
package pursetester;


public class PurseTester {

    
    public static void main(String[] args) {
        Purse purse = new Purse(), other = new Purse();
        purse.addCoin("1");
        purse.addCoin("2");
        purse.addCoin("3");
        purse.addCoin("4");
        purse.addCoin("5");
        other.addCoin("1");
        other.addCoin("2");
        other.addCoin("3");
        other.addCoin("4");
        other.addCoin("5");
        System.out.println("purse: "+purse);
        System.out.println("other: "+other);
        System.out.println("sameContents: "+purse.sameContents(other));
        System.out.println("sameCoins: "+purse.sameCoins(other));
        purse.reverse();
        System.out.println("purse reverse");
        System.out.println("purse: "+purse);
        System.out.println("other: "+other);
        System.out.println("sameContents: "+purse.sameContents(other));
        System.out.println("sameCoins: "+purse.sameCoins(other));
        purse.transfer(other);
        System.out.println("purse transfer other");
        System.out.println("purse: "+purse);
        System.out.println("other: "+other);
        System.out.println("sameContents: "+purse.sameContents(other));
        System.out.println("sameCoins: "+purse.sameCoins(other));
    }
    
}
